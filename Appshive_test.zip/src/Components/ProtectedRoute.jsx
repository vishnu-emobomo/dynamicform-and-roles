import React from "react";
import { Navigate, useLocation } from "react-router-dom";

// Component to handle route protection
const ProtectedRoute = ({ element: Component }) => {
  const location = useLocation();
  const token = sessionStorage.getItem("authToken"); // Check for token in session storage

  // If token exists, render the component, else redirect to login
  return token ? (
    Component
  ) : (
    <Navigate to="/" state={{ from: location }} replace />
  );
};

export default ProtectedRoute;
