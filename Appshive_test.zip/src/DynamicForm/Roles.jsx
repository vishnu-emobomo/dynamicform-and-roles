import React from 'react';

const Roles = () => {
  return (
    <div>
      <h1>Roles</h1>
    </div>
  );
}

export default Roles;
